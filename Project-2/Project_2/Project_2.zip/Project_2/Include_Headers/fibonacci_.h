#include <stdint.h>
#include <stdlib.h>
#include "enums.h"
//#include "TSI_lib.h"


static uint32_t k=0, prev = 0, curr = 1, next;
void fibonacci(void)
{
			GPIOB_PCOR= GPIO_PIN(GREEN_LED);				//Toggles LED.
			if(k != 100)									//Calculates the fibonacci series till 100.
			{
				_fibonacci[k]=curr;
				next = prev + curr;
				prev = curr;
				curr = next;
				k+=1;
			}
			Delay_ms(20);
			GPIOB_PSOR = GPIO_PIN(GREEN_LED);
			Delay_ms(20);
			return 0;
}


