#include "MKL25Z4.h"
#include "enums.h"
#include "fibonacci.h"

void Delay_ms(uint32_t time)                            //Custom delay function, considering the clock frequency to be 20.9175MHz
{
  uint32_t i,j,k;
  for(k=0;k<time;k++){
    for(j=0;j<1000;j++){
      for(i=0;i<21;i++){
        __asm("nop");
    }
    }
  }

}

 void InitLEDsGPIO(void)                                        //Reference __
 {
 // Turn on clock gating to PortB module (red and green LEDs)
 SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK;

 // Turn on clock gating to PortD module (blue LED)
 SIM_SCGC5 |= SIM_SCGC5_PORTD_MASK;

 // Initialize red LED (PTB18)
 PORTB_PCR18 = PORT_PCR_MUX(1); // Set PTB18 pin mux to GPIO
 GPIOB_PSOR |= GPIO_PIN(RED_LED); // Set initial output to high
 GPIOB_PDDR |= GPIO_PIN(RED_LED); // Set pin direction to output

 // Initialize green LED (PTB19)
 PORTB_PCR19 = PORT_PCR_MUX(1);
 GPIOB_PSOR |= GPIO_PIN(GREEN_LED);
 GPIOB_PDDR |= GPIO_PIN(GREEN_LED);

 // Initialize the blue LED (PTD1) // Note different port!
 PORTD_PCR1 = PORT_PCR_MUX(1);
 GPIOD_PSOR = GPIO_PIN(BLUE_LED);
 GPIOD_PDDR |= GPIO_PIN(BLUE_LED);
 } // end InitLEDsGPIO()

 void CalibrateTSI(void)                                         //Reference __
  {
  TSI0_GENCS |= TSI_GENCS_EOSF_MASK; // Clear end of scan flag

  // Scan first electrode (TSI9)
  TSI0_DATA = (TSI9 << TSI_DATA_TSICH_SHIFT);
  TSI0_DATA |= TSI_DATA_SWTS_MASK; // Request scan

  while(!(TSI0_GENCS & TSI_GENCS_EOSF_MASK)); // Spin until done
  TSI0_GENCS |= TSI_GENCS_EOSF_MASK; // Clear end of scan flag
  baselineValue[0] = (TSI0_DATA & TSI_DATA_TSICNT_MASK);

  // Scan second electrode (TSI10)
  TSI0_DATA = (TSI10 << TSI_DATA_TSICH_SHIFT);
  TSI0_DATA |= TSI_DATA_SWTS_MASK; // Request scan

  while(!(TSI0_GENCS & TSI_GENCS_EOSF_MASK)); // Spin until done
  TSI0_GENCS |= TSI_GENCS_EOSF_MASK; // Clear end of scan flag
  baselineValue[1] = (TSI0_DATA & TSI_DATA_TSICNT_MASK);

  TSI0_DATA = (TSI9 << TSI_DATA_TSICH_SHIFT); // Select electrode to scan
  currentElectrode = 0; // Set flag for first electrode

  }

 void InitTSI(void)                                             //Reference __
 {
 SIM_SCGC5 |= SIM_SCGC5_TSI_MASK; // Enable access for TSI

 // Enable GPIO pins as TSI channels
 PORTB_PCR16 = PORT_PCR_MUX(0); // PTB16 as TSI channel 9
 PORTB_PCR17 = PORT_PCR_MUX(0); // PTB17 as TSI channel 10

 TSI0_GENCS |= (TSI_GENCS_ESOR_MASK
 | TSI_GENCS_MODE(0) // Non-noise detection
 | TSI_GENCS_REFCHRG(4) // 8 micro-amp charge
 | TSI_GENCS_DVOLT(0) // Set voltage rails
 | TSI_GENCS_EXTCHRG(7) // Set charge/discharge current
 | TSI_GENCS_PS(4) // Frequency divided by 16
 | TSI_GENCS_NSCN(11) // Scan electrode count
 // | TSI_GENCS_TSIIEN_MASK // No interrupt
 | TSI_GENCS_STPE_MASK
 // | TSI_GENCS_STM_MASK // Scan trigger type software
 // 0 = software
 );

 // Do not enable TSI module until all other settings are in place!
 TSI0_GENCS |= TSI_GENCS_TSIEN_MASK;

 CalibrateTSI();

 } // End InitTSI()

 void SwapElectrode(void)                                                 //Reference __
 {
 // Swap to other electrode
 if(currentElectrode == 0) {
 currentElectrode = 1; // change flag
 // Select the electrode to scan
 TSI0_DATA = (TSI10 << TSI_DATA_TSICH_SHIFT);
 } else {
 currentElectrode = 0;
 TSI0_DATA = (TSI9 << TSI_DATA_TSICH_SHIFT);
 }
 } // end SwapElectrode()

 void ScanTSI(void)                                                         //Reference __
 {
 short delta;
 unsigned short conversionCount[2];

 TSI0_DATA |= TSI_DATA_SWTS_MASK; // Issue a scan

 while(!(TSI0_GENCS & TSI_GENCS_EOSF_MASK)); // Wait to complete
 TSI0_GENCS |= TSI_GENCS_EOSF_MASK; // Clear end of scan flag

 // Mask out counter data of current sample from register and save it
 conversionCount[currentElectrode] = (TSI0_DATA & TSI_DATA_TSICNT_MASK);
 // Compute delta using calibration reference counts
 delta = conversionCount[currentElectrode] - baselineValue[currentElectrode];

 // Handle underflow
 if( delta < 0) {deltaResult[currentElectrode] = 0;}
 else
 deltaResult[currentElectrode] = delta;

 SwapElectrode(); // Switch to other electrode

 } // end ScanTSI()






 unsigned char ReadTSI(void)                                                          //Reference __
 {
 // If there's a touch, calculate its position on slider
 if((deltaResult[0] > THRESHOLD) || (deltaResult[1] > THRESHOLD)){

 SliderPercentagePosition[0] = (deltaResult[0]*100)/(deltaResult[0]+deltaResult[1]);
 SliderPercentagePosition[1] = (deltaResult[1]*100)/(deltaResult[0]+deltaResult[1]);

 absolutePercentagePosition = ((100 - SliderPercentagePosition[0]) + SliderPercentagePosition[1])/2;

 } else { // No touch, purge variables to prevent spurious events
 SliderPercentagePosition[0] = NO_TOUCH;
 SliderPercentagePosition[1] = NO_TOUCH;
 absolutePercentagePosition = NO_TOUCH;
 } // end else

 SliderDistancePosition[0] = (SliderPercentagePosition[0]* SLIDER_LENGTH)/100;
 //sliderDistancePosition[0] = (sliderPercentagePosition[0]* SLIDER_LENGTH)/100;
 SliderDistancePosition[1] = (SliderPercentagePosition[1]* SLIDER_LENGTH)/100;

 absoluteDistancePosition = ((SLIDER_LENGTH - SliderDistancePosition[0]) + SliderDistancePosition[1])/2;

 //return ((unsigned char)absolutePercentagePosition);
 return (absoluteDistancePosition);

 } // end ReadTSI()

 // LENGTH in mm




 #define RANGE 32 // Use when level is a percentage range
 #define DISTANCE 6//6 // Use when level is distance value

 #define RED_RANGE 0
 #define YELLOW_RANGE 1
 #define GREEN_RANGE 2
 #define AQUA_RANGE 3
 #define BLUE_RANGE 4
 #define PURPLE_RANGE 5

 void ChangeLEDColor(volatile uint8_t level)
 {
    char input=0;

  if(level<=15)                                         //If the touch is on left side of the TSI, count is incremented(Clockwise).
  {   if(count==5)count=-1;
      count+=1;
     GPIOB_PSOR = GPIO_PIN(RED_LED); //Green-Blue
     GPIOB_PSOR = GPIO_PIN(GREEN_LED);
     GPIOD_PCOR = GPIO_PIN(BLUE_LED);

     uart0_putstr(functions[count]);
     Delay_ms(25);
     return;
  }
  else if(level>20) //Green-Blue                        //If the touch is on right side of the TSI, count is deremented(Anti-clockwise).
  {   if((count-1)<0)count=6;
    count-=1;
    GPIOB_PSOR = GPIO_PIN(RED_LED);
    GPIOB_PCOR = GPIO_PIN(GREEN_LED);
    GPIOD_PSOR = GPIO_PIN(BLUE_LED);

    uart0_putstr(functions[count]);                    //Displays the option scroled to.
    Delay_ms(25);
    return;


  }
  //uart0_putstr(level);


 } // end ChangeLEDColor()
void LEDsOff(void)                                  //Turns off the LEDs.
{
 GPIOB_PSOR &= ~GPIO_PIN(RED_LED);
 GPIOB_PSOR &= ~GPIO_PIN(GREEN_LED);
 GPIOB_PSOR &= ~GPIO_PIN(BLUE_LED);
}
