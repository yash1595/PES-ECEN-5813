#include "MKL25Z4.h"
#include "enums.h"
#include <string.h>
#include <stdlib.h>

errtype ring_t_init(char data,uint32_t length){                                             //Initialize a circular buffer.
    uint32_t buff_index=0;
    if(mode==BLOCKING){
    for(buff_index=0;buff_index<3;buff_index+=1)                                            //Can allocate upto a specified number 
    {                                                                                       //of independent circular buffers.
        if(CycBuffs[buff_index]==NULL)break;
    }
        if(CycBuffs[buff_index]!=NULL)return CycBuffAllocationError;
    }
    CycBuffs[buff_index]=(ring_t*)malloc(sizeof(ring_t));                                   //Dynamically allocate size for each structure.
    if(CycBuffs[buff_index]==NULL)return CycBuffAllocationError;
    CycBuffs[buff_index]->Ini=0;                                                            //Initialize the structure elements.
    CycBuffs[buff_index]->Outi=0;
    CycBuffs[buff_index]->length=length;
    CycBuffs[buff_index]->full_flag=CLEAR;
    CycBuffs[buff_index]->realloc_flag=CLEAR;
    CycBuffs[buff_index]->buff_flag=CLEAR;
    CycBuffs[buff_index]->buffer = (char*)malloc(CycBuffs[buff_index]->length);             //Dynamically allocate size for each Circular Buffer.
    memset(CycBuffs[buff_index]->buffer,'\0',sizeof(char)*length);                          //Initilaize the buffer with null value.
    if(CycBuffs[buff_index]->buffer==NULL)return BuffAllocationError;                       //Returns if buffer is not allocated.
    index++;

    return Success;
}

errtype AddDataCycBuff(char data,uint32_t buff_index){
    if(flag==FULL){return Buffer_Full;}                                                     //Returns(Nonblocking mode)if buffer is full. 
    if(mode==NONBLOCKING){
    buff_index=0;
    uint32_t next = CycBuffs[buff_index]->Ini+1;                                            //Updates counter to point to a location after head.
    if(next >CycBuffs[buff_index]->length)next=0;                                           //Checks if that location is > than buffer size.
    if(next==CycBuffs[buff_index]->Outi)                                                    //If next == tail, it returns wuth buffer full error.
    {
        flag=FULL;
        return Buffer_Full;
    }

    CycBuffs[buff_index]->buffer[CycBuffs[buff_index]->Ini]=data;                           //Adds data to head.
    CycBuffs[buff_index]->Ini=next;                                                         //Head is updated to next position.
    characters[(uint8_t)data]++;                                                            //Character buffer is updated.
    uart0_putchar(data);
    return Success;
    }

    if(mode==BLOCKING){
    buff_index=-1;
    uart0_putstr("Enter the buffer index:");                                                //Asks user for buffer index.
    while(buff_index==-1)
    {
        buff_index = uart0_strtoint();
        if(allocate_flag!=0)
        {
            if(buff_index>index||CycBuffs[buff_index]==NULL)buff_index=-1;                  //If the specified buffer hasn't been allocated,error is returned.
        }
    }
    if(CycBuffs[buff_index]->full_flag==SET)return Buffer_Full;                             //if the buffer is full, error is returned.
    uint8_t singleton=0;
    uart0_putstr("Enter the characters:");                                                  //User enters characetrs.
    data=uart0_getchar();
    while(data!=13)  //ASCII value of carriage return
          {
            if(singleton!=0){
                uint32_t next = CycBuffs[buff_index]->Ini+1;                                //Updates counter to point to a location after head.
                    if(next>=CycBuffs[buff_index]->length)next=0;                           //If the next is greater than length of buffer, next=0.
                    if(CycBuffs[buff_index]->buff_flag==SET){CycBuffs[buff_index]->Ini=next;next+=1;CycBuffs[buff_index]->buff_flag=CLEAR;}                 //if the buffer is full,it upates head with next and updates next, clearing the flag.
                    if(CycBuffs[buff_index]->Ini>=CycBuffs[buff_index]->length){CycBuffs[buff_index]->Ini=0;next+=1;}                                       //If the head == length, head is set to 0 and next is made 1.
                    CycBuffs[buff_index]->buffer[CycBuffs[buff_index]->Ini]=data;                                                                           //Data is added to head.
                    if(next==CycBuffs[buff_index]->Outi){CycBuffs[buff_index]->buff_flag=SET;CycBuffs[buff_index]->full_flag=SET;return Buffer_Full;}       //If next == tail, buff_flag is set and error is returned.
                    CycBuffs[buff_index]->Ini=next;                                         //Head is updated with next.
          }
    singleton=1;
    data=uart0_getchar();                                                                   //Next character is read.
    uart0_putchar(data);                                                                    //Entered data is displayed.
        }


    }
    return Success;
}

errtype DelDataCycBuff(char data,uint32_t buff_index){
    uart0_putstr("Enter the buffer to delete data:");                                      //Asks for the buffer.
    uint32_t num_of_loc=0;
    buff_index=-1;
    while(buff_index==-1)
    {
        buff_index=uart0_strtoint();
        if(buff_index>index||(CycBuffs[buff_index]==NULL))buff_index=-1;                   //If the buffer exceeds the index value or is null,returns error.
    }
    if(CycBuffs[buff_index]==NULL)return DataDeletionError;
    uart0_putstr("Enter the number of locations:");                                        //Asks for number of locations.
     num_of_loc=-1;
     while(num_of_loc==-1)
    {
         num_of_loc=uart0_strtoint();
         if (num_of_loc==0) num_of_loc=-1;                                                 //While the entered value is not a valid number, it retakes inputs.
    }
    if(num_of_loc >= CycBuffs[buff_index]->length) return DataDeletionError;               //If number of locations>length of buffer, error is returned.
    uint32_t index_value=((CycBuffs[buff_index]->Outi)+num_of_loc)%(CycBuffs[buff_index]->length);          //Takes the entered value and calculates its index value.
    if(index_value==0 || CycBuffs[buff_index]->buffer[((index_value)-1)]=='\0') return Buffer_Full;         //If the value is <0 or NULL returns error.
    errtype value=0;
    uint32_t next,i=0;
    for(i=0;i<num_of_loc;i++){
        next = CycBuffs[buff_index]->Outi+1;
        if(next>=CycBuffs[buff_index]->length)next=0;                                      //If next>length of buffer, next=0.
        if(CycBuffs[buff_index]->Outi==CycBuffs[buff_index]->Ini){                         //If the tail==head, returns an error.
            return Buffer_Full;
        }
        CycBuffs[buff_index]->buffer[CycBuffs[buff_index]->Outi]='\0';                     //Puts a '\0' in the valid locations.
        CycBuffs[buff_index]->Outi=next;//=next;
    }
    CycBuffs[buff_index]->full_flag=CLEAR;                                                 //Clears the buffer full flag.
    return Success;
}

errtype DisplayCycBuff(char data,uint32_t buff_index){
    uint32_t index,i=0,sum=0;
    buff_index=-1;
    uart0_putstr("Enter the buffer index:");                                                //Asks for the index.
    while(buff_index==-1)
    {
    buff_index= uart0_strtoint();
    if(buff_index>index||CycBuffs[buff_index]==NULL)buff_index=-1;                          //If invalid, retakes input.
    }
    uint32_t next=CycBuffs[buff_index]->Outi;                                               //Next pointer is equal to Tail.
    if(CycBuffs[buff_index]->Ini<CycBuffs[buff_index]->Outi){                               //If head < tail, prints out the values from tail to length of buffer.
        for(i=next;i<CycBuffs[buff_index]->length;i++){uart0_putchar(CycBuffs[buff_index]->buffer[i]);sum++;}       
        next=0;
    }
    if(next<=CycBuffs[buff_index]->Ini){                                                    //If the tail < head, prints out from tail to head.
        for(i=next;i<=CycBuffs[buff_index]->Ini;i++){uart0_putchar(CycBuffs[buff_index]->buffer[i]);sum++;}
    }
    uart0_putstr("\nSum:");
    uart0_inttostr(sum);                                                                    //Displays the sum.
    return Success;
}

errtype Allocate(char data,uint32_t length)
{
    errtype AllocateStatus=-1;
    uart0_putstr("Enter the length of the buffer:");                                        //Asks for user input.
    length=-1;
    while(length==-1)length = uart0_strtoint();                                             //Retakes inputs till valid.
    if(index>BUFFSIZE)return Buffer_Full;                                                   //if index>number of buffers that can be allocated; returns error.
    AllocateStatus= ring_t_init(data,length);                                               //Allocates a new buffer.
    return AllocateStatus;
}

errtype DisplayAllBuffers(char data, uint32_t length)                                       //Displays the index of buffers and their sizes.
{
    uint32_t size=0,rev=0,count=0;
    for(size=0;size<BUFFSIZE;size+=1){
        uart0_putchar(size+'0');
        uart0_putstr(" : ");
        if(CycBuffs[size]==NULL)uart0_putchar(32);
        else{
            if(CycBuffs[size]->length<10)uart0_putstr(CycBuffs[size]->length+'0');      
            uint32_t num=CycBuffs[size]->length;
            uart0_inttostr(num);
        }
        uart0_putchar('\n');
    }
    return Success;
}
errtype FreeMem(char data,uint32_t buff_index)                                              //Frees the entered buffer at index.
{
        errtype FreeStatus=-1;
        DisplayAllBuffers(0,0);                                                             //Shows the buffers' index and their size.
        buff_index=-1;
        while(buff_index==-1)
        {
        uart0_putstr("Enter the index of the buffer\n");                                    //Asks for user inputs.
        buff_index = uart0_strtoint();
        if(buff_index>index)buff_index=-1;
        }
        if(buff_index>index)return FreeingError;                                            //If index entered>max.possible index, returns an error.
        if(CycBuffs[buff_index]==NULL)return FreeingError;                                  //If the buffer at index is NULL, returns error.
        free(CycBuffs[buff_index]->buffer);                                                 //Frees the buffer at buff_index.
        CycBuffs[buff_index]->buffer=NULL;                                                  //Assigns a NULL to it.
        free(CycBuffs[buff_index]);                                                         //Frees the structure.
        CycBuffs[buff_index]=NULL;                                                          //Assigns a NULL.
        index-=1;
        return Success;
}

errtype FreeAll(char data,uint32_t buff_index)                                              //Frees all memory locations.
{
    errtype FreeStatus=-1;
    uint8_t k=0;
    for(k;k<10;k+=1)free(CycBuffs[k]);
    return FreedCycBuffs;
}

errtype ReallocBuff(char data,uint32_t buff_index)                                          //reallocates buffer sizes.
{
    uint32_t index,i=0,resize=0;
    buff_index=-1;
    uart0_putstr("Enter the buffer index:");                                                //Asks for index.
    while(buff_index==-1)
    {
        buff_index = uart0_strtoint();
        if(buff_index>index||CycBuffs[buff_index]==NULL)buff_index=-1;                      //Retakes values till a valid one is entered.
        if(buff_index<0 || buff_index>255)return Buffer_Full;
    }
    uart0_putstr("Enter the new size:");                                                    //Asks for a new size.Must be > than allocated size.
    resize=-1;
    while(resize==-1){
    resize = uart0_strtoint();
    if(resize>255 || resize<0)resize=-1;
    }
    if(resize<=CycBuffs[buff_index]->length)return BuffAllocationError;                     
    CycBuffs[buff_index]->buffer = (char*)realloc(CycBuffs[buff_index]->buffer,resize);    //Realloc.
    CycBuffs[buff_index]->length=resize;                                                   //Updates the structure variable length to new size.
    if(CycBuffs[buff_index]->buffer==NULL)return BuffAllocationError;                      //If allocated buffer is NULL, returns error.
    CycBuffs[buff_index]->realloc_flag=SET;                                                //Sets the realloc flag.
    return Success;

}
